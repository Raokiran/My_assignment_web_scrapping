I used langchain_community.document_loaders to  import WebBaseLoader for web scrapping The content.
I used  langchain_community.vectorstores  to import FAISS for vectorbase
I used langchain_community.embeddings  to import HuggingFaceEmbeddings for embedding 
